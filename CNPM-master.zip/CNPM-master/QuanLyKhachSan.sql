-- Script tạo database, các bảng và dữ liệu mẫu cho hệ thống quản lý khách sạn

-- Tạo database
CREATE DATABASE IF NOT EXISTS QuanLyKhachSan CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE QuanLyKhachSan;

-- Bảng Phòng
CREATE TABLE IF NOT EXISTS Phong (
    MaPhong VARCHAR(10) PRIMARY KEY,
    TenPhong VARCHAR(100) NOT NULL,
    KieuPhong VARCHAR(50) NOT NULL,
    GiaPhong INT NOT NULL,
    TinhTrang VARCHAR(50) NOT NULL
);

INSERT INTO Phong (MaPhong, TenPhong, KieuPhong, GiaPhong, TinhTrang) VALUES
('R001', 'Phòng Trang Trọng', 'Đơn', 400000, 'Trống'),
('R002', 'Phòng Tiêu Chuẩn', 'Đơn', 200000, 'Trống'),
('R003', 'Phòng Cao Cấp', 'Đôi', 1200000, 'Đang thuê'),
('R004', 'Phòng Gia Đình', 'Gia đình', 1500000, 'Trống'),
('R005', 'Phòng Suite', 'Suite', 2500000, 'Đang thuê'),
('R006', 'Phòng Deluxe', 'Đôi', 1000000, 'Cần dọn dẹp');

-- Bảng Khách Hàng
CREATE TABLE IF NOT EXISTS KhachHang (
    MaKH VARCHAR(10) PRIMARY KEY,
    TenKH VARCHAR(100) NOT NULL,
    Email VARCHAR(100),
    GioiTinh VARCHAR(10),
    CMND_CCCD VARCHAR(20) NOT NULL,
    SDT VARCHAR(15) NOT NULL,
    DiaChi VARCHAR(200),
    NgaySinh DATE
);

INSERT INTO KhachHang (MaKH, TenKH, Email, GioiTinh, CMND_CCCD, SDT, DiaChi, NgaySinh) VALUES
('KH001', 'Nguyễn Văn A', 'a@gmail.com', 'Nam', '123456789', '0909123456', 'Hà Nội', '1990-01-01'),
('KH002', 'Trần Thị B', 'b@gmail.com', 'Nữ', '987654321', '0912345678', 'Hồ Chí Minh', '1995-05-20'),
('KH003', 'Lê Văn C', 'c@gmail.com', 'Nam', '456789123', '0987654321', 'Đà Nẵng', '1988-12-12'),
('KH004', 'Phạm Thị D', 'd@gmail.com', 'Nữ', '321654987', '0932123456', 'Hải Phòng', '1992-07-15');

-- Bảng Đặt Phòng
CREATE TABLE IF NOT EXISTS DatPhong (
    MaDatPhong VARCHAR(10) PRIMARY KEY,
    Phong VARCHAR(100) NOT NULL,
    HoTen VARCHAR(100) NOT NULL,
    SDT VARCHAR(15) NOT NULL,
    Email VARCHAR(100),
    NhanPhong DATE NOT NULL,
    TraPhong DATE NOT NULL,
    TrangThai VARCHAR(50) NOT NULL
);

INSERT INTO DatPhong (MaDatPhong, Phong, HoTen, SDT, Email, NhanPhong, TraPhong, TrangThai) VALUES
('DP001', 'Phòng Cao Cấp', 'Nguyễn Văn A', '0909123456', 'a@gmail.com', '2025-05-10', '2025-05-15', 'Đã nhận phòng'),
('DP002', 'Phòng Suite', 'Trần Thị B', '0912345678', 'b@gmail.com', '2025-05-11', '2025-05-16', 'Đã đặt'),
('DP003', 'Phòng Tiêu Chuẩn', 'Lê Văn C', '0987654321', 'c@gmail.com', '2025-05-09', '2025-05-12', 'Đã trả phòng'),
('DP004', 'Phòng Gia Đình', 'Phạm Thị D', '0932123456', 'd@gmail.com', '2025-05-14', '2025-05-18', 'Đã đặt');

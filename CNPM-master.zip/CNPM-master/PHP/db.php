<?php
// db.php - Kết nối database cho hệ thống quản lý khách sạn
$host = 'localhost'; // hoặc IP database server
$user = 'root';      // tài khoản MySQL
$pass = '';          // mật khẩu MySQL
$db = 'quanlykhachsan'; // tên database, đổi lại đúng tên bạn dùng

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die('Kết nối database thất bại: ' . $conn->connect_error);
}
$conn->set_charset('utf8');
?>

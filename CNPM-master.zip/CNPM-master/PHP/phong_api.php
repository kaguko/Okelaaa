<?php
// phong_api.php - API quản lý phòng cho hệ thống quản lý khách sạn (theo action)
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list':
        $result = $conn->query('SELECT * FROM phong');
        $phongs = [];
        while ($row = $result->fetch_assoc()) {
            $phongs[] = $row;
        }
        echo json_encode(['success' => true, 'data' => $phongs]);
        break;
    case 'add':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['name'], $data['type'], $data['price'], $data['status'])) {
            echo json_encode(['success' => false, 'message' => 'Thiếu thông tin phòng!']);
            exit;
        }
        // Tạo mã phòng tự động
        $result = $conn->query('SELECT MaPhong FROM phong ORDER BY MaPhong DESC LIMIT 1');
        $last = $result->fetch_assoc();
        $nextId = 'R001';
        if ($last && preg_match('/R(\d+)/', $last['MaPhong'], $m)) {
            $nextId = 'R' . str_pad(((int)$m[1]) + 1, 3, '0', STR_PAD_LEFT);
        }
        $stmt = $conn->prepare('INSERT INTO phong (MaPhong, TenPhong, KieuPhong, GiaPhong, TinhTrang) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('sssis', $nextId, $data['name'], $data['type'], $data['price'], $data['status']);
        $success = $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => $success]);
        break;
    case 'update':
        $data = json_decode(file_get_contents('php://input'), true);
        $oldCode = isset($data['oldCode']) ? $data['oldCode'] : null;
        $newCode = isset($data['newCode']) ? $data['newCode'] : null;
        if (!$oldCode || !$newCode || !isset($data['name'], $data['type'], $data['price'], $data['status'])) {
            echo json_encode(['success' => false, 'message' => 'Thiếu thông tin phòng!']);
            exit;
        }
        // Kiểm tra trùng mã phòng (nếu đổi mã phòng)
        if ($oldCode !== $newCode) {
            $check = $conn->prepare('SELECT MaPhong FROM phong WHERE MaPhong=?');
            $check->bind_param('s', $newCode);
            $check->execute();
            $check->store_result();
            if ($check->num_rows > 0) {
                $check->close();
                echo json_encode(['success' => false, 'message' => 'Dữ liệu bị trùng, vui lòng nhập lại']);
                exit;
            }
            $check->close();
            $stmt = $conn->prepare('UPDATE phong SET MaPhong=?, TenPhong=?, KieuPhong=?, GiaPhong=?, TinhTrang=? WHERE MaPhong=?');
            $stmt->bind_param('sssiss', $newCode, $data['name'], $data['type'], $data['price'], $data['status'], $oldCode);
        } else {
            // Kiểm tra trùng tên phòng (TenPhong) nếu cần
            $check = $conn->prepare('SELECT MaPhong FROM phong WHERE TenPhong=? AND MaPhong<>?');
            $check->bind_param('ss', $data['name'], $oldCode);
            $check->execute();
            $check->store_result();
            if ($check->num_rows > 0) {
                $check->close();
                echo json_encode(['success' => false, 'message' => 'Dữ liệu bị trùng, vui lòng nhập lại']);
                exit;
            }
            $check->close();
            $stmt = $conn->prepare('UPDATE phong SET TenPhong=?, KieuPhong=?, GiaPhong=?, TinhTrang=? WHERE MaPhong=?');
            $stmt->bind_param('ssiss', $data['name'], $data['type'], $data['price'], $data['status'], $oldCode);
        }
        $success = $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => $success]);
        break;
    case 'delete':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['code'])) {
            echo json_encode(['success' => false, 'message' => 'Thiếu mã phòng!']);
            exit;
        }
        $stmt = $conn->prepare('DELETE FROM phong WHERE MaPhong=?');
        $stmt->bind_param('s', $data['code']);
        $success = $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => $success]);
        break;
    case 'search':
        $data = json_decode(file_get_contents('php://input'), true);
        $code = isset($data['code']) ? $conn->real_escape_string($data['code']) : '';
        $phongs = [];
        if ($code) {
            // Cho phép tìm kiếm theo nhiều trường: mã phòng, tên phòng, kiểu phòng, tình trạng
            $sql = "SELECT * FROM phong WHERE MaPhong LIKE '%$code%' OR TenPhong LIKE '%$code%' OR KieuPhong LIKE '%$code%' OR TinhTrang LIKE '%$code%'";
            $result = $conn->query($sql);
        } else {
            $result = $conn->query("SELECT * FROM phong");
        }
        while ($row = $result->fetch_assoc()) {
            $phongs[] = $row;
        }
        echo json_encode(['success' => true, 'data' => $phongs]);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Action không hợp lệ!']);
}
?>

<?php
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Kết nối database qua file db.php
require_once __DIR__ . '/db.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list':
        $result = $conn->query('SELECT * FROM khachhang');
        if (!$result) {
            echo json_encode(['success' => false, 'message' => 'Lỗi truy vấn: ' . $conn->error]);
            exit;
        }
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'MaKH' => $row['MaKH'],
                'TenKH' => $row['TenKH'],
                'Email' => $row['Email'],
                'GioiTinh' => $row['GioiTinh'],
                'CMND_CCCD' => $row['CMND_CCCD'],
                'SDT' => $row['SDT'],
                'DiaChi' => $row['DiaChi'],
                'NgaySinh' => $row['NgaySinh']
            ];
        }
        echo json_encode($data);
        break;
    case 'add':
        $input = json_decode(file_get_contents('php://input'), true);
        $maKH = $conn->real_escape_string($input['maKH']);
        $ten = $conn->real_escape_string($input['ten']);
        $email = $conn->real_escape_string($input['email']);
        $gioiTinh = $conn->real_escape_string($input['gioiTinh']);
        $cmnd = $conn->real_escape_string($input['cmnd']);
        $sdt = $conn->real_escape_string($input['sdt']);
        $diaChi = $conn->real_escape_string($input['diaChi']);
        $ngaySinh = $conn->real_escape_string($input['ngaySinh']);
        $sql = "INSERT INTO khachhang (MaKH, TenKH, Email, GioiTinh, CMND_CCCD, SDT, DiaChi, NgaySinh) VALUES ('$maKH', '$ten', '$email', '$gioiTinh', '$cmnd', '$sdt', '$diaChi', '$ngaySinh')";
        if ($conn->query($sql)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => $conn->error]);
        }
        // Hiển thị tất cả sau khi thêm
        break;
    case 'update':
        $input = json_decode(file_get_contents('php://input'), true);
        $maKH = $conn->real_escape_string($input['maKH']);
        $ten = $conn->real_escape_string($input['ten']);
        $email = $conn->real_escape_string($input['email']);
        $gioiTinh = $conn->real_escape_string($input['gioiTinh']);
        $cmnd = $conn->real_escape_string($input['cmnd']);
        $sdt = $conn->real_escape_string($input['sdt']);
        $diaChi = $conn->real_escape_string($input['diaChi']);
        $ngaySinh = $conn->real_escape_string($input['ngaySinh']);
        $sql = "UPDATE khachhang SET TenKH='$ten', Email='$email', GioiTinh='$gioiTinh', CMND_CCCD='$cmnd', SDT='$sdt', DiaChi='$diaChi', NgaySinh='$ngaySinh' WHERE MaKH='$maKH'";
        if ($conn->query($sql)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => $conn->error]);
        }
        // Hiển thị tất cả sau khi sửa
        break;
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $maKH = $conn->real_escape_string($input['maKH']);
        $sql = "DELETE FROM khachhang WHERE MaKH='$maKH'";
        if ($conn->query($sql)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => $conn->error]);
        }
        // Hiển thị tất cả sau khi xóa
        break;
    case 'search':
        $input = json_decode(file_get_contents('php://input'), true);
        $search = $conn->real_escape_string($input['search']);
        $sql = "SELECT * FROM khachhang WHERE MaKH LIKE '%$search%' OR TenKH LIKE '%$search%' OR Email LIKE '%$search%' OR GioiTinh LIKE '%$search%' OR CMND_CCCD LIKE '%$search%' OR SDT LIKE '%$search%' OR DiaChi LIKE '%$search%'";
        $result = $conn->query($sql);
        if (!$result) {
            echo json_encode(['success' => false, 'message' => 'Lỗi truy vấn: ' . $conn->error]);
            exit;
        }
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'MaKH' => $row['MaKH'],
                'TenKH' => $row['TenKH'],
                'Email' => $row['Email'],
                'GioiTinh' => $row['GioiTinh'],
                'CMND_CCCD' => $row['CMND_CCCD'],
                'SDT' => $row['SDT'],
                'DiaChi' => $row['DiaChi'],
                'NgaySinh' => $row['NgaySinh']
            ];
        }
        echo json_encode($data);
        // Hiển thị tất cả sau khi tìm kiếm (nếu muốn reset thì gọi lại list ở client)
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Action không hợp lệ']);
}
$conn->close();
?>

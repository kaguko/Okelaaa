<?php
// datphong_api.php - API quản lý đặt phòng cho hệ thống khách sạn
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list':
        $result = $conn->query('SELECT * FROM datphong');
        $bookings = [];
        while ($row = $result->fetch_assoc()) {
            $bookings[] = $row;
        }
        echo json_encode(['success' => true, 'data' => $bookings]);
        break;
    case 'cancel':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['id'])) {
            echo json_encode(['success' => false, 'message' => 'Thiếu mã đặt phòng!']);
            exit;
        }
        $stmt = $conn->prepare('UPDATE datphong SET TrangThai=? WHERE MaDatPhong=?');
        $status = 'Đã hủy';
        $stmt->bind_param('ss', $status, $data['id']);
        $success = $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => $success]);
        break;
    case 'checkin':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['id'])) {
            echo json_encode(['success' => false, 'message' => 'Thiếu mã đặt phòng!']);
            exit;
        }
        $stmt = $conn->prepare('UPDATE datphong SET TrangThai=? WHERE MaDatPhong=?');
        $status = 'Đã nhận phòng';
        $stmt->bind_param('ss', $status, $data['id']);
        $success = $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => $success]);
        break;
    case 'checkout':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['id'])) {
            echo json_encode(['success' => false, 'message' => 'Thiếu mã đặt phòng!']);
            exit;
        }
        $stmt = $conn->prepare('UPDATE datphong SET TrangThai=? WHERE MaDatPhong=?');
        $status = 'Đã trả phòng';
        $stmt->bind_param('ss', $status, $data['id']);
        $success = $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => $success]);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Action không hợp lệ!']);
}
?>
